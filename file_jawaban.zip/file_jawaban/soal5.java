import java.util.Scanner;

class soal5 {
    public static void main(String[]args){
        int a, b, c, hasil=0;
        Scanner scan=new Scanner(System.in);
        c=scan.nextInt();
        
        if(c>=1 && c<=105){
            int counter=0;
            for(a=1;a<=c;a++){
                for(b=1;b<=c;b++){
                    if(((a*a)+(b*b))==(c*c)){
                        counter++;
                    }
                }
            }
            System.out.println(counter);
        }
    }
}