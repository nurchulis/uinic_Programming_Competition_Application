#include <cstdio>

using namespace std;

long long k;
bool g=false;

void kali(long long a,long long b)
{
	if(b==0)
	{
		k=0;
		return;
	}
	if(b==1)
	{
		k=a;
		return;
	}
	kali(a,b/2);
	k+=k;
	if(b%2==1)
	{
		k+=a;
	}
}

int main()
{
	long long a,b,c,z,d=0;
	
	scanf("%lld%lld%lld",&a,&b,&c);
	if(a<0)
	{
		a-=a+a;
		g=!g;
	}
	if(b<0)
	{
		b-=b+b;
		g=!g;
	}
	if(c<0)
	{
		c-=c+c;
		g=!g;
	}
	kali(a,b);
	z=k;
	while(z>=c)
	{
		z-=c;
		d++;
	}
	if(g)
	{
		d-=d+d;
	}
	printf("%lld\n",d);
}
