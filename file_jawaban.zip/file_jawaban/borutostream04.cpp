#include <iostream>
#include <string>
using namespace std;
int main(){
string x;
string j = "\\(^_^)/";
string k = ">.<\"";
string l = "('')\?";
cin >> x;

if(x=="semangat"){
cout << x << j;}
else if(x=="sebel"){
cout << x << k;}
else if(x=="bingung"){
cout << x << l;}

return 0;}