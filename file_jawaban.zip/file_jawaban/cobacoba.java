import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
public class cobacoba{
    public static void main(String[] args){
       BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        try{
            String inp=bf.readLine();
            if(inp.equals("semangat")){
                System.out.println(inp+" \\(^_^)/");
            }else if(inp.equals("sebel")){
                System.out.println(inp+" >.<\"");
            }else if(inp.equals("bingung")){
                System.out.println(inp+" (\'\')?");
            }else{
                 System.out.println("invalid input");   
            }

        }catch(IOException ex){
            System.out.println(ex.toString());
        }
    }
}