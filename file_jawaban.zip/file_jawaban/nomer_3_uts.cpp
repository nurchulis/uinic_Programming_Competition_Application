#include <iostream>
using namespace std;
int main()
{
	int n[4]={100,101,102,103};
	for (int i=0;i<4;i++){
		cout<<"elemen ke ="<<n[i]<<endl;
		
	}
	
		
	
	system("pause");
}
