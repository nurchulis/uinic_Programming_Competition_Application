    import java.io.InputStreamReader;
    import java.io.BufferedReader;
    import java.io.IOException;
public class miawmiawyoi{
    public static void main(String[] args){
        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        try{
            String inp= bf.readLine();
            int count=0;boolean hasSpace=false;
            if(inp.charAt(0)=='M'&&!inp.contains(" ")){
            for(int i =0;i<inp.length();i++){
              
                    if(inp.charAt(i)=='M'){count++;
                }}
                System.out.println(count);
                
            }else{System.out.println("Invalid input");}
        }catch(IOException ex){
            System.out.println(ex.toString());
        }
    }
}