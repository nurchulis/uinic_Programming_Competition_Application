#include <iostream>

using namespace std;

int main()
{
	int a, b, c, d;

	cin >> d;
	
	for(int i = 1; i <= d-2; i++)
	{
		a = i;

		for(int j = 1; j <= d-2 ; j++)
		{
			b = j;

			c = d-(a+b);

			if ( c < 1)
				break;

			cout << a << " " << b << " " << c <<endl;
			
		}
		
	}
	

	// 1 1 4
	// 1 2 3
	// 1 3 2
	// 1 4 1
	// 2 1 3
	// 2 2 2
	// 2 3 1
	// 3 1 2
	// 3 2 1
	// 4 1 1

	return 0;
}