#include <iostream>

using namespace std;

int main()
{
	int a, b, c , kali, hasil;

	cin >> a >> b >> c;

	if (b == 1)
	{
		kali = a;
	}
	else
	{
		int temp_a = a;
		
		for(int i = 1; i < b ; i++)
		{
			a = a + temp_a;
			kali = a;
		}
	}

	do
	{
		kali = kali - c;
		if( kali < 0 )
			break;
		hasil++;
	}while( kali > 0);
		
	cout << hasil << endl;
	
	return 0;
}