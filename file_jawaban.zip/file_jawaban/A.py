'''
 Separator inputnya pakai <spasi><koma><spasi> ya mas
 Kalo engga nanti program saya error

 contoh:
 5 , 5 , 2

 bukan:
 5 5 2 atau 5, 5, 2
'''
a, b, c = map(int, input().strip().split(' , '))

i = a;

while b > 1:
	i += a
	b -= 1

ans = i

j = ans
k = 0

while j >= c:
	j -= c
	k += 1

ans = k

print(ans)