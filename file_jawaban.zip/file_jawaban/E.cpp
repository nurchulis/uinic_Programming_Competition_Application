#include <iostream>
#include <string>
#include <vector>
#include <cmath>
#include <map>
#include <set>
#include <algorithm>
#include <stack>
#include <queue>

#define ll long long
#define md 1000000007

#define vi vector<int>
#define append push_back
#define ALL(a) a.begin(), a.end()

#define ii pair<int, int>
#define fi first
#define se second
#define mp make_pair

#define si set<int>
#define mii map<int, int>
#define msi map<string, int>
#define pi priority_queue<int>
using namespace std;

int a, b, c;

int main() {
	cin >> c;
	a = 1;
	int ans = 0;

	while (a < c) {
		int t = c*c - a*a;
		int u = sqrt((double) t);

		if (u * u == t) {
			ans++;
		}

		a++;
	}

	cout << ans << endl;

	return 0;
}
