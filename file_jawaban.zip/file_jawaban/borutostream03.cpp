#include <iostream>
#include <algorithm>

using namespace std;

int main()

{
    int SIZE;

    cin >> SIZE;

    int a[SIZE];
    int terkecil;
    
    for(int i = 0; i < SIZE ; i++)
		cin >> a[i];

    terkecil = *min_element(a, a+SIZE);

    cout<< terkecil;
    return 0;
}
