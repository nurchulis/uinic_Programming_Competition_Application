#include<bits/stdc++.h>
using namespace std;
int n, a, jwb=9999;
int main(){
	cin>>n;
	for(int i=1; i<=n; i++){
		cin>>a;
		jwb= min(jwb, a);
	}
	cout<<jwb;
}
