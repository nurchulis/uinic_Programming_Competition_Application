#include<bits/stdc++.h>
using namespace std;

int a;

int main() {
	a = 11;
	for(int i=0; i<11; i++) {
		int b = abs(i-5);
		for(int j=0; j< 5-b ; j++) {
			cout<<' ';
		}
		cout<<'*';
		for(int j=0 ; j<b*2-1	; j++) {
			cout<<' ';
		}
		if(b>0)cout<<'*';
		cout<<endl;
	}
}
