#include<bits/stdc++.h>
using namespace std;

int N;

int main () {
	ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
	
	cin >> N;
	for (int i=1; i<=N-2; i++) {
		for (int j=1; j<=N-i-1; j++) {
			cout << i << " " << j << " " << N-i-j << '\n';
		}
	}
}
