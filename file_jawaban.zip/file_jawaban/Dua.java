import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
//using java 11
class Dua{
    public static void main(String[] args) {
        int intN =0,temp = 0;
        String input ="";
        BufferedReader br =new BufferedReader(new InputStreamReader(System.in));

        try{
        String n = br.readLine();
        intN = Integer.parseInt(n);
        int[] deret = new int[intN];
        input = br.readLine();

        if(input.length() < intN * 2){
            for(int i = 0; i < input.length(); i++){
            if(i%2 == 0){
                 char objek = input.charAt(i);
                String opo = String.valueOf(objek);
                int tenanan = Integer.parseInt(opo);
                deret[temp] = tenanan;
                temp ++;
            }
        }
    
        int minimal = deret[0];

        for(int j = 0; j < intN;j++){
            if(minimal > deret[j]){
                minimal = deret[j];
            }
        }

        System.out.println(minimal);
    }else{
            System.out.println("invalid input");
        }
    }catch(IOException e){
        System.out.println(e);
    }
    }
}