class Satu{
    public static void main(String[] args) {
        int temp = 0;
        int[][] koordinat = {{1,10},
                            {2,9},
                            {3,8},
                            {4,7},
                            {5,6},
                            {6},
                            {5,6},
                            {4,7},
                            {3,8},
                            {2,9},
                            {1,10}
                            };
        for(int i =0;i <= koordinat.length - 1;i++){
            for(int j = 0;j <= koordinat[i][koordinat[i].length - 1]; j++){
                if(j == koordinat[i][temp]){
                    System.out.print("*");
                    temp++;
                }else{
                    System.out.print(" ");
                }
            }
            temp = 0;
            System.out.print("\n");
        }

    }
}