#include<iostream>
#include<conio.h>
#include<stdio.h>

using namespace std;

int main()
{
char nama[20],alamat[100];
cout<<"Masukkan nama   : "<<gets(nama);
cout<<endl;
cout<<"Masukkan alamat : "<<gets(alamat);
cout<<endl<<endl;

cout<<"Data anda adalah !"<<endl;
cout<<"Nama   : "<<nama<<endl;
cout<<"Alamat : "<<alamat<<endl;

getch();

return 0;
}
