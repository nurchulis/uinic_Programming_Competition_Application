#include<bits/stdc++.h>
using namespace std;
string s;
int main(){
	cin>>s;
	if(s=="semangat") cout<<"semangat "<<'\\'<<"(^_^)/";
	else if(s=="sebel") cout<<"sebel >.<"<<'"';
	else cout<<"bingung (' ')?";	
}
