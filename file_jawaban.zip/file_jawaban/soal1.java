import java.util.Scanner;

class soal1 {
    public static void main(String[]args){
        int x,y,z,temp=0,hasil=0;
        Scanner scan = new Scanner(System.in);
        x= scan.nextInt();
        y=scan.nextInt();
        z=scan.nextInt();
        for(int i=1;i<=y;i++){
            temp+=x;
        }
        hasil=Integer.divideUnsigned(temp,z);
        System.out.println(hasil);
    }
}