import java.util.Scanner;

class soal4{
    public static void main(String[]args){
        int x, n, temp, data;
       
        Scanner scan=new Scanner(System.in);
        n=scan.nextInt();
        int arr[]=new int[n];
        for(int i=0;i<n;i++){
            data=scan.nextInt();
            if(data>=1 && data<=200){
                arr[i]=data;
            }
        }
        if(n>=1 && n<=20){
        for(int i=0; i<arr.length-1; i++) {
         for(int j = i+1; j<arr.length; j++){
            if(arr[i] < arr[j]){
               temp = arr[i]; 
               arr[i] = arr[j];
               arr[j] = temp; 
            }           
         }
        }
        System.out.print(arr[n-1]);
        }
    }
}