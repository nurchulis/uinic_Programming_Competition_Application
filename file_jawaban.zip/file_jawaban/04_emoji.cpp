#include <iostream>

using namespace std;

int main()
{
	string s;
	cin>>s;
	cout<<s<<" ";
	if(s=="semangat")
	{
		cout<<"\\(^_^)/\n";
	}
	else if(s=="sebel")
	{
		cout<<">.<\"\n";
	}
	else if(s=="bingung")
	{
		cout<<"(\' \')?\n";
	}
}
