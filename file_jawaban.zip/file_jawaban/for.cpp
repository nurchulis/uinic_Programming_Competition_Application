#include<iostream>
using namespace std;
int main(){
	int a;
	for (i=10;i<=14;i++);
	cout<<a;
}
