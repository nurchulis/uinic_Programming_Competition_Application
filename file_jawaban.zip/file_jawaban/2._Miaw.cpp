#include <bits/stdc++.h>
using namespace std ;

long long ans ;
string s ;

int main(){
	
	cin >> s ;
	
	long long l1 = s.length() ;
	
	for(int i = 0 ; i < l1-3 ; i++){
		
		if(s[i]=='M'){
			if(s[i+1]=='i'){
				if(s[i+2]=='a'){
					if(s[i+3]=='w'){
						ans++;
					}
				}
			}
		}
		
	}
	
	cout << ans << "\n" ;
	
}
